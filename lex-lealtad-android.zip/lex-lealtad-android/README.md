# Lex Lealtad - APK Android

Esta es una app Android tipo WebView para abrir directamente la tarjeta de lealtad digital de Barber Shop by Lex.

## Que hace

- Abre directo: https://lex-lealtad.toadies-lake-8gwyz4p.chatgpt.site
- No pide inicio de sesion al cliente.
- Permite usar camara para escanear QR cuando el celular/navegador interno lo soporte.
- Mantiene el PIN de administrador dentro del sitio: `LEX2026`.

## Como generar la APK en Android Studio

1. Abre Android Studio.
2. Elige **Open** y selecciona esta carpeta: `lex-lealtad-android`.
3. Espera a que sincronice Gradle.
4. Para una APK de prueba: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Para una APK lista para enviar: **Build > Generate Signed Bundle / APK > APK**.
6. Crea una llave nueva, guarda la contrasena y genera la APK release.

## Donde queda el archivo

- APK de prueba: `app/build/outputs/apk/debug/app-debug.apk`
- APK firmada: Android Studio te preguntara la carpeta de salida.

## Nota importante

El codigo de la app es nativo Android y ligero. La informacion de clientes y visitas se guarda en la base de datos del sitio publicado, no dentro del celular.
